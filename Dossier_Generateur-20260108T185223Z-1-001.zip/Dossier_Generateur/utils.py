import pandas as pd

def csv_to_text(file_obj) -> str:
    """
    Lit un fichier CSV, le nettoie et le convertit en texte Markdown.
    Version sécurisée qui limite la taille pour éviter les erreurs 429.
    """
    if not file_obj:
        return ""
    try:
        # 1. Lecture du fichier
        df = pd.read_csv(file_obj)

        # 2. NETTOYAGE : On supprime les lignes et colonnes totalement vides
        df.dropna(how='all', axis=0, inplace=True) # Supprime les lignes vides
        df.dropna(how='all', axis=1, inplace=True) # Supprime les colonnes vides

        # 3. LIMITATION : On ne garde que les 60 premières lignes
        # (L'IA n'a pas besoin de plus pour comprendre le contexte ou le modèle)
        if len(df) > 60:
            df = df.head(60)
            warning = "\n(Note: Le fichier a été tronqué aux 60 premières lignes pour l'IA)"
        else:
            warning = ""

        # 4. Conversion en texte Markdown
        # On remplit les cases vides (NaN) par du vide "" pour éviter d'écrire "nan" partout
        return df.fillna("").to_markdown(index=False) + warning

    except Exception as e:
        return f"Erreur de lecture du fichier : {e}"

def format_history(injects: list) -> str:
    """
    Formate l'historique des injects pour l'IA.
    """
    if not injects:
        return "Aucun événement généré pour l'instant (Début du scénario)."
    
    text = ""
    for i, item in enumerate(injects):
        # On simplifie l'historique pour économiser des tokens
        text += f"- T{item.get('time', '?')}: {item.get('title', 'Event')}\n"
    return text