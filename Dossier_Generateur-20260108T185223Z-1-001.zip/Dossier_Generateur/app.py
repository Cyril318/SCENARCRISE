import streamlit as st
from ai import ScenarioGenerator
from utils import csv_to_text, format_history

st.set_page_config(page_title="Générateur de Chronogramme", layout="wide")

# 1. Initialisation de l'état (mémoire de l'application)
if 'injects' not in st.session_state:
    st.session_state.injects = [] # Liste des injects générés

st.title("⚡ Générateur de Chronogramme de Crise")

# --- SIDEBAR : CONFIGURATION ---
with st.sidebar:
    st.header("1. Configuration")
    api_key = st.text_input("Clé API Gemini", type="password")
    
    st.header("2. Données d'entrée")
    context_file = st.file_uploader("📂 CSV Contexte (Lieu/Acteurs)", type=["csv"])
    model_file = st.file_uploader("📂 CSV Modèle (Ex: Incendie)", type=["csv"])

    st.markdown("---")
    if st.button("🗑️ Réinitialiser le scénario"):
        st.session_state.injects = []
        st.rerun()

# --- MAIN : GÉNÉRATION ---
if not api_key:
    st.warning("Veuillez entrer une clé API OpenAI pour commencer.")
    st.stop()

generator = ScenarioGenerator(api_key)

# Affichage du scénario existant
st.subheader(f"Chronogramme ({len(st.session_state.injects)} événements)")

for i, inject in enumerate(st.session_state.injects):
    with st.expander(f"📍 {inject.get('time')} - {inject.get('title')}", expanded=True):
        st.write(f"**Description :** {inject.get('description')}")
        st.caption(f"👥 Destinataires : {inject.get('destinataires')}")

# Zone de commande pour la suite
st.markdown("---")
st.subheader("Générer la suite")

col1, col2 = st.columns([3, 1])
with col1:
    guidance = st.text_input("Instruction pour l'IA (Optionnel)", placeholder="Ex: Les pompiers sont bloqués par la foule...")
with col2:
    generate_btn = st.button("Générer +3 Injects ✨", type="primary", use_container_width=True)

if generate_btn:
    if not context_file or not model_file:
        st.error("Veuillez charger les fichiers CSV Contexte et Modèle.")
    else:
        with st.spinner("L'IA rédige la suite du scénario..."):
            # 1. Préparation des données
            context_str = csv_to_text(context_file)
            model_str = csv_to_text(model_file)
            history_str = format_history(st.session_state.injects)

            # 2. Appel IA
            new_injects = generator.generate_batch(context_str, model_str, history_str, guidance)

            # 3. Mise à jour
            if new_injects:
                st.session_state.injects.extend(new_injects)
                st.success("3 nouveaux événements ajoutés !")
                st.rerun()
            else:
                st.error("L'IA n'a pas renvoyé de résultat valide.")