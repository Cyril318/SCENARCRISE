import json
from openai import OpenAI

class ScenarioGenerator:
    def __init__(self, api_key: str):
        self.client = OpenAI(api_key=api_key) if api_key else None

    def generate_batch(self, context_str: str, model_str: str, history_str: str, user_guidance: str) -> list:
        if not self.client:
            return []

        # 1. DÉTECTION DU MOMENT (Début vs Suite)
        is_start = len(history_str) < 50 or "Aucun événement" in history_str
        
        if is_start:
            phase_instruction = """
            🔴 PHASE : INITIALISATION (H+00).
            - Ne commence PAS par le chaos. Commence par l'élément déclencheur (le "bruit faible").
            - Pose le décor calmement avant de faire monter la pression.
            """
        else:
            phase_instruction = """
            🟠 PHASE : DÉVELOPPEMENT & COHÉRENCE.
            - Tu n'as plus besoin de regarder le modèle. Regarde l'HISTORIQUE.
            - Tes nouveaux événements doivent être la conséquence STRICTE et LOGIQUE de ce qui vient de se passer.
            - Si l'utilisateur donne une instruction, elle devient ta priorité absolue.
            """

        # 2. LE SYSTEM PROMPT (C'est ici qu'on bloque le recopiage)
        system_prompt = """
        Tu es un Scénariste de Crise Créatif.
        
        RÈGLES D'OR (A RESPECTER SOUS PEINE D'ÉCHEC) :
        1. INTERDICTION TOTALE de copier les événements, les noms ou les lieux du "Fichier Modèle".
        2. Le "Fichier Modèle" sert UNIQUEMENT à comprendre la structure (ex: "Ah, il faut un appel téléphonique ici", ou "Il faut un tweet ici").
        3. Le CONTENU (Qui, Quoi, Où) doit venir EXCLUSIVEMENT du "Fichier Contexte" et de ton imagination.
        4. COHÉRENCE : Si un bâtiment brûle à H+1, il ne peut pas être intact à H+2. Vérifie toujours la logique causale.
        """
        
        # 3. LE USER PROMPT (On sépare bien les sources)
        user_prompt = f"""
        === SOURCE 1 : LA VÉRITÉ (Le Contexte) ===
        Utilise ces données pour les vrais noms, les vrais lieux et les moyens réels :
        {context_str}

        === SOURCE 2 : L'INSPIRATION ABSTRAITE (Le Modèle) ===
        Regarde ce fichier juste pour voir le STYLE attendu (format, brièveté). 
        ATTENTION : Ne reprends AUCUNE information factuelle de ce tableau.
        {model_str}

        === MÉMOIRE (L'Historique) ===
        Ce qui s'est passé jusqu'ici :
        {history_str}

        === CONSIGNE DE PHASE ===
        {phase_instruction}

        === ORDRE DE L'UTILISATEUR ===
        "{user_guidance if user_guidance else "Invente la suite logique."}"

        === TÂCHE ===
        Génère 3 injects originaux.
        Format JSON :
        {{
            "injects": [
                {{
                    "time": "H+XX:XX",
                    "title": "Titre",
                    "description": "Description...",
                    "destinataires": "Rôles"
                }}
            ]
        }}
        """

        try:
            response = self.client.chat.completions.create(
                model="gpt-4o-mini", 
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                response_format={"type": "json_object"},
                temperature=0.8 # Assez haut pour forcer l'invention, pas la copie
            )
            
            content = response.choices[0].message.content
            data = json.loads(content)
            return data.get("injects", [])

        except Exception as e:
            print(f"Erreur OpenAI : {e}")
            return []